package com.example.drawer_widget_studioxd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
