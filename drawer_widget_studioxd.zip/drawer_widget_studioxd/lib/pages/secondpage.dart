// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

class Secondpage extends StatelessWidget{
  const Secondpage ({super.key});
  @override 
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title: Center(child: Text('Second Page')),backgroundColor: Colors.deepPurple[400],),
        
      );
    
  }
}